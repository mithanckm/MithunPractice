var express =  require('express');
var path = require('path');
var mongoose = require('mongoose');
var bodyParser = require("body-parser");
var nodemailer = require('nodemailer');
var moment = require('moment');
var crypto = require('crypto');
var coupon = require('./coupongenerate');
var async = require('async');
var app = express();
app.use(bodyParser.json());
app.use(express.static('public'));
app.use(bodyParser.urlencoded({
    extended: true
}));
app.set('view engine', 'pug');
mongoose.connect('mongodb://localhost:27017/vouchermanagment');
var db = mongoose.connection;
db.on('error', console.log.bind(console, "connection error"));
db.once('open', function(callback){
    console.log("connection succeeded");
})
var currentdate =new Date().getTime()
var key = "supersecretkey";

// Generation of Coupon Code Saving to DB
app.post('/savecopon',function (req,res)
{

    var cipher = crypto.createCipher('aes-256-cbc', key);
    var crypted = cipher.update(coupon.coupongenerator(), 'utf-8', 'hex');
    crypted += cipher.final('hex');
    var fname = req.body.fname;
    var lname = req.body.lname;
    var Email = req.body.email;
    var listofcoupons = crypted;
    var CoponWorth = req.body.amount;
    var ExpiryDate = parseInt(currentdate+86400000);
    var Expdate = moment(ExpiryDate);

    var data = {
        "name": fname+""+lname,
        "email":Email,
        "CoupongenDate":currentdate,
        "CoponWorth":CoponWorth,
        "CouponCode":listofcoupons,
        "ExpiryDate":Expdate.format('LLLL'),
        "PartiallyUsed":0,
         "PreviousUsedtime":""
    }

    db.collection('coupondetails').insertOne(data,function(err, collection){
        if (err) throw err;
        console.log("Record inserted Successfully");
    });
    //Email part
    var transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: 'mithuninfo94@gmail.com',
            pass: '9844043467'
        }
    });
    var mailOptions = {
        from: 'mithuninfo94@gmail.com',
        to: Email,
        subject: "Coupon From Online Shopping  Mithun India",
        text:'Dear Mr/Ms'+""+fname+""+lname+""+'Please Use this Coupon Before Expiry'+""+'Coupon Worth'+":"+CoponWorth+"Coupon Code"+
            ""+coupon.coupongenerator()+""+'ExpiryDate'+Expdate.format('LLLL')
    };

    transporter.sendMail(mailOptions, function(error, info){
        if (error) {
            console.log(error);
        } else {
            console.log('Email sent: ' + info.response);
        }
    });

    db.collection('coupondetails').findOne({CouponCode:listofcoupons}, function(err, user) {
        if (err) throw err;
        console.log(user)
        var decipher = crypto.createDecipher('aes-256-cbc', key);
        var decrypted = decipher.update(user.CouponCode, 'hex', 'utf-8');
        decrypted += decipher.final('utf-8');
        res.render('coupondetail', { title: 'coupounvoucher', message:decrypted,Expirydate:user.ExpiryDate,CoponWorth:user.CoponWorth,
        UserMail:user.email,Name:user.name})
    });

})

app.get('/createcoupon',function (req,res)
{
    res.redirect( '/couponcreation.html');
})

// Get filter based on email and Coupon
app.get('/FilterByEmail/:id',function (req,res)
{
    db.collection('coupondetails').findOne({email:req.params.id}, function(err, user) {
        if (err) throw err;
        console.log(user)
        var decipher = crypto.createDecipher('aes-256-cbc', key);
        var decrypted = decipher.update(user.CouponCode, 'hex', 'utf-8');
        decrypted += decipher.final('utf-8');
        res.render('coupondetail', { title: 'coupounvoucher', message:decrypted,Expirydate:user.ExpiryDate,CoponWorth:user.CoponWorth,
            UserMail:user.email,Name:user.name})
    });
})

app.get('/FilterByCoupon/:id',function (req,res)
{
    var usercoupon = req.params.id;
    var amount = parseInt(req.body.amount);
    var cipher = crypto.createCipher('aes-256-cbc', key);
    var crypted = cipher.update(usercoupon, 'utf-8', 'hex');
    crypted += cipher.final('hex');
    db.collection('coupondetails').findOne({CouponCode:crypted}, function(err, user) {
        if (err) throw err;
        console.log(user)
        var decipher = crypto.createDecipher('aes-256-cbc', key);
        var decrypted = decipher.update(user.CouponCode, 'hex', 'utf-8');
        decrypted += decipher.final('utf-8');
        res.render('coupondetail', { title: 'coupounvoucher', message:decrypted,Expirydate:user.ExpiryDate,CoponWorth:user.CoponWorth,
            UserMail:user.email,Name:user.name})
    });
})

app.get('/FilterByGenerationTime',function (req,res) {
    res.redirect('/filterDateWise.html');
})
app.post('/getvochersbygendate',function (req,res)
{
    var fromdate =  new Date(req.body.fromdate).getTime();
    var todate =  new Date(req.body.todate).getTime();
    db.collection('coupondetails').find({
        "CoupongenDate": {
            $gte:fromdate.toString(),
            $lt:todate.toString()
        }
    },function(err, user) {
        if (err) throw err;
        console.log(user)
    });
})

app.get('/usecoupon',function (req,res)
{
    res.redirect('/Usecoupon.html');
})

app.post('/usebyparticular',function (req,res)
{
    var usercoupon = req.body.couponcode;
    var amount = parseInt(req.body.amount);
    var cipher = crypto.createCipher('aes-256-cbc', key);
    var crypted = cipher.update(usercoupon, 'utf-8', 'hex');
    crypted += cipher.final('hex');
    var amountBydb;
    var couponUtilize;
    var previousUsedtime;
    function first(){
        db.collection('coupondetails').findOne({CouponCode:crypted}, function(err, user) {
            if (err) throw err;
            console.log(user)
            if(user == null){
                return res.send('Entered Coupon is not user Valid ')
            }
            var decipher = crypto.createDecipher('aes-256-cbc', key);
            var decrypted = decipher.update(user.CouponCode, 'hex', 'utf-8');
            decrypted += decipher.final('utf-8');
            amountBydb= parseInt(user.CoponWorth);
            couponUtilize = parseInt(user.PartiallyUsed)+1;
            previousUsedtime = parseInt(user.PreviousUsedtime);
            second();
        });  
    }
    function second()
    {
        var usedTime = new Date().getTime();
        var diff = usedTime-previousUsedtime;
        if(couponUtilize>5)
        {
            return res.send('Your number of used coupon time is more than 5 ');

        }

        else if( (diff) <= 600000)
        {
            return res.send('Please you Cont Use this coupon Now please Use after 10 Min');
        }

        else if( amount <= amountBydb  &&  amountBydb>1  && amount >=1)
        {
            db.collection("coupondetails").update({CouponCode:crypted},{
             $set: {CoponWorth:amountBydb-amount,PartiallyUsed:couponUtilize,
                 PreviousUsedtime:usedTime},
            }, function(err, res) {
                if (err) throw err;
            });
            res.send('Successfully Used your Copupn Remain Coupon Worth is you can  use next time'+ (amount-amountBydb));
        }

        else  {
            res.send('you cont use coupon your vouhcer amount Exceed');
        }
    }
    first();
})

app.listen(400,() =>{
    console.log('Server is Running.....');
})
