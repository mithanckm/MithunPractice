function coupongenerator() {

         var suffix = "";
         var possible = "0123456789";
         for (var i = 0; i < possible.length; i++) {
             suffix += possible.charAt(Math.floor(Math.random() * possible.length));
         }
         var prefix = "";
         var possible1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

         for (var i = 0; i < possible1.length; i++) {
             if(i<3){
                 prefix += possible1.charAt(Math.floor(Math.random() * possible1.length));
             }
         }
     return prefix+""+suffix;

}
module.exports.coupongenerator = coupongenerator;